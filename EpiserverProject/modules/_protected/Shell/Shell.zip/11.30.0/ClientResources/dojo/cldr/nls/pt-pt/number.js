//>>built
define("dojo/cldr/nls/pt-pt/number",{"group":" ","decimalFormat-long":"000 biliões","currencyFormat":"#,##0.00 ¤","decimalFormat-short":"000 Bi","decimal":","});